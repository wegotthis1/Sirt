import { Suspense, useEffect, useMemo, useRef, useState } from "react"
import type { FormEvent } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import type { Group, PerspectiveCamera, Points as ThreePoints } from "three"
import { BufferGeometry, Float32BufferAttribute } from "three"
import { useGSAP } from "@gsap/react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { AnimatePresence, motion } from "framer-motion"
import {
  ArrowDown,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Asterisk,
  ChevronLeft,
  ChevronRight,
  Menu,
  MoveUpRight,
  Phone,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

gsap.registerPlugin(ScrollTrigger, useGSAP)

const collegeUrl = "https://www.sirtbhopal.ac.in/"
const edcUrl = "https://www.sirtbhopal.ac.in/entrepreneurship-development-cell"
const heroScrollMotion = { progress: 0 }
const galleryImages = [
  { src: "https://www.sirtbhopal.ac.in/assets/uploads/edc/0.jpg", title: "Ideas in motion", index: "01" },
  { src: "https://www.sirtbhopal.ac.in/assets/uploads/edc/1%20%282%29.jpg", title: "Learning together", index: "02" },
  { src: "https://www.sirtbhopal.ac.in/assets/uploads/edc/11.webp", title: "Built at SIRT", index: "03" },
  { src: "https://www.sirtbhopal.ac.in/assets/uploads/edc/12.webp", title: "The next big thing", index: "04" },
]

const programs = [
  {
    number: "01",
    title: "Awareness camps",
    copy: "Get closer to entrepreneurship: the mindset, the messy middle, and the steps between an idea and a venture.",
    tag: "LEARN THE LANDSCAPE",
    color: "lime",
    mark: "01",
  },
  {
    number: "02",
    title: "Idea presentations",
    copy: "Put a thought on the table. Practise explaining the problem, the people it matters to, and your first solution.",
    tag: "MAKE THE PITCH",
    color: "orange",
    mark: "02",
  },
  {
    number: "03",
    title: "Startup bootcamp",
    copy: "Build business planning, communication, e-marketing, and digital promotion skills one practical step at a time.",
    tag: "BUILD YOUR TOOLKIT",
    color: "violet",
    mark: "03",
  },
]

const activities = [
  {
    date: "2024 / PITCH",
    title: "A pitch that placed first.",
    body: "The SIRT EDC team Pani Wala won an inter-university business pitching competition at JLU Bhopal.",
    category: "STUDENT VENTURE",
    number: "01",
  },
  {
    date: "2024 / LEARN",
    title: "Startup schemes, IPR & more.",
    body: "An Entrepreneurship Awareness Programme with CEDMAP introduced students to government startup schemes and intellectual property rights.",
    category: "AWARENESS PROGRAMME",
    number: "02",
  },
  {
    date: "2023 / ENVISAGE",
    title: "Ideas take the stage.",
    body: "EnviSage invited student teams from SIRT, SIRTE, and SIRTSP to showcase their business plans.",
    category: "IDEA SHOWCASE",
    number: "03",
  },
]

const teamMembers = [
  { name: "Member Name", role: "President", index: "01" },
  { name: "Member Name", role: "Vice President", index: "02" },
  { name: "Member Name", role: "Operations & Events", index: "03" },
  { name: "Member Name", role: "Startup & Innovation", index: "04" },
  { name: "Member Name", role: "Design & Media", index: "05" },
  { name: "Member Name", role: "Marketing & Outreach", index: "06" },
]

function IdeaCore() {
  const core = useRef<Group>(null)
  const orbit = useRef<Group>(null)
  const points = useRef<ThreePoints>(null)
  const desiredRotation = useRef({ x: 0, y: 0 })
  const dragging = useRef(false)
  const { gl } = useThree()
  const pointGeometry = useMemo(() => {
    const geometry = new BufferGeometry()
    const positions = Array.from({ length: 330 }, () => [
      (Math.random() - 0.5) * 13,
      (Math.random() - 0.5) * 9,
      (Math.random() - 0.5) * 6,
    ]).flat()
    geometry.setAttribute("position", new Float32BufferAttribute(positions, 3))
    return geometry
  }, [])

  useEffect(() => {
    const canvas = gl.domElement
    const beginDrag = (event: PointerEvent) => {
      dragging.current = true
      canvas.setPointerCapture(event.pointerId)
    }
    const rotate = (event: PointerEvent) => {
      if (!dragging.current) return
      desiredRotation.current.y += event.movementX * 0.006
      desiredRotation.current.x += event.movementY * 0.006
      desiredRotation.current.x = Math.max(-0.9, Math.min(0.9, desiredRotation.current.x))
    }
    const endDrag = () => { dragging.current = false }
    canvas.addEventListener("pointerdown", beginDrag)
    canvas.addEventListener("pointermove", rotate)
    canvas.addEventListener("pointerup", endDrag)
    canvas.addEventListener("pointercancel", endDrag)
    return () => {
      canvas.removeEventListener("pointerdown", beginDrag)
      canvas.removeEventListener("pointermove", rotate)
      canvas.removeEventListener("pointerup", endDrag)
      canvas.removeEventListener("pointercancel", endDrag)
    }
  }, [gl])

  useFrame((state, delta) => {
    if (core.current) {
      if (!dragging.current) desiredRotation.current.y += delta * 0.13 + state.pointer.x * delta * 0.07
      desiredRotation.current.x += -state.pointer.y * delta * 0.025
      const scrollTilt = heroScrollMotion.progress * 0.32
      core.current.rotation.y += (desiredRotation.current.y + scrollTilt - core.current.rotation.y) * Math.min(delta * 5, 1)
      core.current.rotation.x += (desiredRotation.current.x + scrollTilt * 0.55 - core.current.rotation.x) * Math.min(delta * 5, 1)
      core.current.rotation.z = Math.sin(heroScrollMotion.progress * Math.PI) * 0.18
      core.current.scale.setScalar(1.14 + heroScrollMotion.progress * 0.11)
      core.current.position.y = Math.sin(state.clock.elapsedTime * 0.72) * 0.1
    }
    if (orbit.current) {
      orbit.current.rotation.z += delta * 0.045
      orbit.current.rotation.x = 0.35 + heroScrollMotion.progress * 0.4
      orbit.current.scale.setScalar(1.08)
    }
    if (points.current) points.current.rotation.y = state.pointer.x * 0.035
  })

  return (
    <>
      <color attach="background" args={["#080808"]} />
      <ambientLight intensity={0.6} />
      <pointLight position={[4, 3, 4]} intensity={45} color="#ff3142" />
      <pointLight position={[-4, -2, 2]} intensity={25} color="#ffffff" />
      <pointLight position={[0, 0, -5]} intensity={30} color="#168fe5" />
      <points ref={points} geometry={pointGeometry}>
        <pointsMaterial size={0.018} color="#ffffff" transparent opacity={0.42} sizeAttenuation />
      </points>
      <group ref={orbit}>
        <mesh rotation={[1.18, 0.25, -0.34]}>
          <torusGeometry args={[1.72, 0.008, 8, 160]} />
          <meshBasicMaterial color="#ed1c2e" transparent opacity={0.82} />
        </mesh>
        <mesh rotation={[0.48, 1.23, 0.7]}>
          <torusGeometry args={[2.02, 0.006, 8, 160]} />
          <meshBasicMaterial color="#168fe5" transparent opacity={0.74} />
        </mesh>
        <mesh rotation={[1.7, 0.2, 1.1]}>
          <torusGeometry args={[2.23, 0.005, 8, 160]} />
          <meshBasicMaterial color="#dfdbca" transparent opacity={0.36} />
        </mesh>
        <mesh position={[1.41, 0.74, 0.12]}>
          <sphereGeometry args={[0.065, 16, 16]} />
          <meshBasicMaterial color="#ed1c2e" toneMapped={false} />
        </mesh>
        <mesh position={[-1.68, -0.38, 0.24]}>
          <sphereGeometry args={[0.045, 16, 16]} />
          <meshBasicMaterial color="#168fe5" toneMapped={false} />
        </mesh>
      </group>
      <group ref={core}>
          <mesh>
            <icosahedronGeometry args={[1.16, 1]} />
            <meshPhysicalMaterial
              color="#ed1c2e"
              emissive="#5c0710"
              emissiveIntensity={0.4}
              metalness={0.78}
              roughness={0.17}
              clearcoat={1}
              clearcoatRoughness={0.08}
              flatShading
            />
          </mesh>
          <mesh scale={1.008}>
            <icosahedronGeometry args={[1.16, 1]} />
            <meshBasicMaterial color="#ffffff" wireframe transparent opacity={0.29} />
          </mesh>
          <mesh position={[0, 0, 1.11]}>
            <circleGeometry args={[0.47, 6]} />
            <meshBasicMaterial color="#ffffff" transparent opacity={0.9} side={2} />
          </mesh>
          <mesh position={[0, 0, 1.125]}>
            <circleGeometry args={[0.34, 6]} />
            <meshBasicMaterial color="#1a1d12" side={2} />
          </mesh>
          <mesh position={[0, 0, 1.14]}>
            <circleGeometry args={[0.21, 6]} />
            <meshBasicMaterial color="#ed1c2e" side={2} />
          </mesh>
      </group>
    </>
  )
}

function WebGLScene() {
  const [webglReady, setWebglReady] = useState(true)
  const compactViewport = typeof window !== "undefined" && window.matchMedia("(max-width: 720px)").matches
  return (
    <div className="hero-canvas" aria-label="Interactive 3D orbiting idea sculpture. Drag to rotate." role="img">
      {webglReady ? (
        <Canvas
          dpr={compactViewport ? [1, 1.15] : [1, 1.45]}
          camera={{ position: [0, 0, 6.7], fov: 44 }}
          gl={{ antialias: true, alpha: false, powerPreference: compactViewport ? "low-power" : "high-performance" }}
          onCreated={({ gl }) => gl.domElement.addEventListener("webglcontextlost", () => setWebglReady(false), { once: true })}
        >
          <Suspense fallback={null}><ResponsiveHeroCamera /><IdeaCore /></Suspense>
        </Canvas>
      ) : <div className="webgl-fallback" aria-hidden="true"><span>e.</span></div>}
      <div className="scene-hud scene-hud-top"><span>LIVE IDEA / 01</span><span>DRAG TO ORBIT&nbsp; ↗</span></div>
      <div className="scene-hud scene-hud-bottom"><span>23°15' N&nbsp; / &nbsp;77°24' E</span><span>SIRT · BHOPAL</span></div>
      <span className="scene-crosshair crosshair-one" />
      <span className="scene-crosshair crosshair-two" />
    </div>
  )
}

function ResponsiveHeroCamera() {
  const { camera, size } = useThree()

  useEffect(() => {
    if (!("fov" in camera)) return
    const perspectiveCamera = camera as PerspectiveCamera
    const aspect = size.width / Math.max(size.height, 1)
    const width = 5.4
    const distance = 6.7
    perspectiveCamera.fov = Math.min(74, Math.max(42, 2 * Math.atan(width / (2 * distance * aspect)) * (180 / Math.PI)))
    perspectiveCamera.position.set(0, 0, distance)
    perspectiveCamera.updateProjectionMatrix()
  }, [camera, size.width, size.height])

  return null
}

function SectionSceneModel({ variant }: { variant: "orbit" | "impact" | "programs" | "team" }) {
  const assembly = useRef<Group>(null)
  const primary = variant === "orbit" || variant === "programs" ? "#ed1c2e" : "#168fe5"
  const secondary = variant === "orbit" || variant === "team" ? "#168fe5" : "#ed1c2e"

  useFrame((state, delta) => {
    if (!assembly.current) return
    assembly.current.rotation.y += delta * 0.2 + state.pointer.x * delta * 0.08
    assembly.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.42) * 0.16 + state.pointer.y * 0.1
    assembly.current.rotation.z = Math.sin(state.clock.elapsedTime * 0.26) * 0.06
  })

  return (
    <group ref={assembly}>
      <mesh scale={variant === "programs" ? 1.16 : variant === "team" ? 0.68 : 1}>
        <icosahedronGeometry args={[0.77, variant === "programs" ? 1 : 0]} />
        <meshPhysicalMaterial color={primary} emissive={primary} emissiveIntensity={0.28} metalness={0.82} roughness={0.16} clearcoat={1} flatShading />
      </mesh>
      <mesh rotation={[0.78, 0.42, 0.15]}>
        <torusGeometry args={[1.15, 0.012, 8, 128]} />
        <meshBasicMaterial color={secondary} transparent opacity={0.88} />
      </mesh>
      <mesh rotation={[1.18, -0.3, 0.68]}>
        <torusGeometry args={[1.38, 0.008, 8, 128]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0.55} />
      </mesh>
      <mesh position={[0.84, 0.55, 0.26]}>
        <octahedronGeometry args={[0.14, 0]} />
        <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.5} metalness={0.3} roughness={0.2} />
      </mesh>
      <mesh position={[-0.86, -0.48, -0.18]}>
        <sphereGeometry args={[0.08, 20, 20]} />
        <meshBasicMaterial color={secondary} toneMapped={false} />
      </mesh>
      {variant === "programs" && <>
        <mesh rotation={[0.4, 0.8, -0.2]}><torusGeometry args={[1.58, 0.006, 8, 160]} /><meshBasicMaterial color="#ffffff" transparent opacity={0.42} /></mesh>
        <mesh position={[0.1, 1.45, 0]}><tetrahedronGeometry args={[0.13, 0]} /><meshBasicMaterial color="#168fe5" toneMapped={false} /></mesh>
      </>}
      {variant === "team" && Array.from({ length: 6 }, (_, index) => <mesh key={index} position={[Math.cos(index * Math.PI / 3) * 1.16, Math.sin(index * Math.PI / 3) * 1.16, Math.sin(index * Math.PI / 1.5) * 0.28]} rotation={[index * 0.3, index * 0.48, index * 0.2]}>
        <octahedronGeometry args={[0.13 + (index % 2) * 0.035, 0]} />
        <meshPhysicalMaterial color={index % 2 ? "#ffffff" : secondary} emissive={index % 2 ? "#ffffff" : secondary} emissiveIntensity={0.34} metalness={0.48} roughness={0.16} />
      </mesh>)}
    </group>
  )
}

function SectionScene({ variant }: { variant: "orbit" | "impact" | "programs" | "team" }) {
  const compactViewport = typeof window !== "undefined" && window.matchMedia("(max-width: 720px)").matches
  return (
    <div className={`section-scene section-scene-${variant}`} data-parallax aria-hidden="true">
      <Canvas dpr={compactViewport ? [1, 1.1] : [1, 1.35]} camera={{ position: [0, 0, 4.6], fov: 38 }} gl={{ antialias: true, alpha: true, powerPreference: "low-power" }}>
        <ambientLight intensity={0.9} />
        <pointLight position={[2, 2, 3]} intensity={22} color={variant === "orbit" || variant === "programs" ? "#ed1c2e" : "#168fe5"} />
        <pointLight position={[-2, -1, 2]} intensity={14} color="#ffffff" />
        <SectionSceneModel variant={variant} />
      </Canvas>
    </div>
  )
}

function SectionHeading({
  eyebrow,
  title,
  accent,
  note,
}: {
  eyebrow: string
  title: string
  accent?: string
  note?: string
}) {
  const headingLabel = [title, accent].filter(Boolean).join(" ")
  return (
    <div className="section-heading js-reveal">
      <div><div className="eyebrow lime-text">{eyebrow}</div><h2 aria-label={headingLabel}><SplitWords text={title} />{accent && <em><SplitWords text={accent} /></em>}</h2></div>
      {note && <KineticCopy className="section-note" text={note} />}
    </div>
  )
}

function SplitWords({ text }: { text: string }) {
  return <>{text.trim().split(/\s+/).map((word, index) => <span className="word-mask" key={`${word}-${index}`} aria-hidden="true"><span className="word-face">{word}</span></span>)}</>
}

function SplitChars({ text }: { text: string }) {
  return <>{Array.from(text).map((character, index) => <span className="hero-char" key={`${character}-${index}`} aria-hidden="true">{character === " " ? "\u00a0" : character}</span>)}</>
}

function KineticCopy({ text, className }: { text: string; className?: string }) {
  return <p className={`kinetic-copy ${className ?? ""}`} aria-label={text}><SplitWords text={text} /></p>
}

function CursorFX() {
  const cursor = useRef<HTMLDivElement>(null)
  const follower = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const finePointer = window.matchMedia("(pointer: fine) and (prefers-reduced-motion: no-preference)")
    const cursorNode = cursor.current
    const followerNode = follower.current
    if (!finePointer.matches || !cursorNode || !followerNode) return

    document.body.classList.add("cursor-ready")
    gsap.set([cursorNode, followerNode], { xPercent: -50, yPercent: -50 })
    const moveX = gsap.quickTo(cursorNode, "x", { duration: 0.12, ease: "power3.out" })
    const moveY = gsap.quickTo(cursorNode, "y", { duration: 0.12, ease: "power3.out" })
    const followX = gsap.quickTo(followerNode, "x", { duration: 0.42, ease: "power3.out" })
    const followY = gsap.quickTo(followerNode, "y", { duration: 0.42, ease: "power3.out" })
    const onMove = (event: PointerEvent) => {
      moveX(event.clientX)
      moveY(event.clientY)
      followX(event.clientX)
      followY(event.clientY)
    }
    const onOver = (event: PointerEvent) => {
      const target = (event.target as HTMLElement | null)?.closest<HTMLElement>("a, button, [data-cursor-label]")
      followerNode.dataset.label = target?.dataset.cursorLabel || (target?.tagName === "BUTTON" ? "CLICK" : target ? "OPEN" : "")
      followerNode.classList.toggle("is-active", Boolean(target))
    }
    const onDown = () => followerNode.classList.add("is-pressed")
    const onUp = () => followerNode.classList.remove("is-pressed")
    document.addEventListener("pointermove", onMove)
    document.addEventListener("pointerover", onOver)
    document.addEventListener("pointerdown", onDown)
    document.addEventListener("pointerup", onUp)

    return () => {
      document.body.classList.remove("cursor-ready")
      document.removeEventListener("pointermove", onMove)
      document.removeEventListener("pointerover", onOver)
      document.removeEventListener("pointerdown", onDown)
      document.removeEventListener("pointerup", onUp)
      gsap.killTweensOf([cursorNode, followerNode])
    }
  }, [])

  return <div className="cursor-layer" aria-hidden="true"><div className="cursor-dot" ref={cursor} /><div className="cursor-follower" ref={follower} /></div>
}

function App() {
  const page = useRef<HTMLDivElement>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [teamIndex, setTeamIndex] = useState(0)
  const [email, setEmail] = useState("")
  const [formMessage, setFormMessage] = useState("")
  const [joinMessage, setJoinMessage] = useState("")

  useGSAP(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return

    const entrance = gsap.timeline({ defaults: { ease: "power3.out" } })
    entrance
      .from(".hero-eyebrow", { y: 22, opacity: 0, duration: 0.7 })
      .fromTo(".hero-title .hero-char", { yPercent: 120, rotateX: -75, opacity: 0 }, { yPercent: 0, rotateX: 0, opacity: 1, duration: 0.85, stagger: 0.035, ease: "back.out(1.25)" }, "-=0.32")
      .from(".hero-description, .hero-actions", { y: 18, opacity: 0, duration: 0.65, stagger: 0.1 }, "-=0.34")
      .from(".hero-canvas", { opacity: 0, scale: 0.76, rotateY: -14, z: -180, duration: 1.35 }, "-=0.72")

    gsap.utils.toArray<HTMLElement>(".js-reveal").forEach((element) => {
      if (element.classList.contains("section-heading")) return
      gsap.from(element, {
        y: 76,
        z: -120,
        rotateX: 9,
        scale: 0.94,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
        transformPerspective: 1400,
        transformOrigin: "50% 50%",
        scrollTrigger: { trigger: element, start: "top 88%", once: true },
      })
    })

    gsap.to(".hero-scene-wrap", {
      yPercent: 16,
      ease: "none",
      scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: true },
    })
    gsap.to(".hero-coordinate", {
      y: -55,
      rotateY: -12,
      ease: "none",
      scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: true },
    })

    gsap.to(".hero-grid", {
      backgroundPositionY: "180px",
      opacity: 0.46,
      ease: "none",
      scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: 0.9 },
    })

    gsap.utils.toArray<HTMLElement>(".section-heading").forEach((heading) => {
      gsap.fromTo(heading, { rotateX: 10, z: -100, transformPerspective: 1200 }, {
        rotateX: 0,
        z: 0,
        ease: "none",
        scrollTrigger: { trigger: heading, start: "top 94%", end: "top 48%", scrub: 0.65 },
      })
      gsap.fromTo(heading.querySelectorAll<HTMLElement>(".word-face"), { yPercent: 118, rotateX: -66, opacity: 0 }, {
        yPercent: 0,
        rotateX: 0,
        opacity: 1,
        duration: 0.95,
        stagger: { each: 0.055, from: "start" },
        ease: "power4.out",
        scrollTrigger: { trigger: heading, start: "top 87%", once: true },
      })
    })

    gsap.utils.toArray<HTMLElement>(".program-card").forEach((card, index) => {
      gsap.fromTo(card, { y: 68, z: -150, rotateY: index % 2 ? 12 : -12, opacity: 0, transformPerspective: 1300 }, {
        y: 0,
        z: 0,
        rotateY: 0,
        opacity: 1,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: { trigger: card, start: "top 88%", once: true },
      })
    })

    gsap.utils.toArray<HTMLElement>(".kinetic-copy").forEach((copy) => {
      gsap.fromTo(copy.querySelectorAll<HTMLElement>(".word-face"), { yPercent: 105, opacity: 0, rotateX: -24 }, {
        yPercent: 0,
        opacity: 1,
        rotateX: 0,
        duration: 0.7,
        stagger: 0.018,
        ease: "power3.out",
        scrollTrigger: { trigger: copy, start: "top 91%", once: true },
      })
    })

    gsap.utils.toArray<HTMLElement>(".gallery-meta").forEach((meta, index) => {
      gsap.fromTo(meta, { y: 40, rotateX: index % 2 ? -14 : 14, z: -70, transformPerspective: 1100 }, {
        y: 0,
        rotateX: 0,
        z: 0,
        ease: "none",
        scrollTrigger: { trigger: meta.closest(".gallery-card"), start: "top bottom", end: "center 48%", scrub: 0.7 },
      })
    })

    gsap.to(heroScrollMotion, {
      progress: 1,
      ease: "none",
      scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: 0.7 },
    })

    const teamScrollIndex = { value: -1 }
    ScrollTrigger.create({
      trigger: ".team-carousel",
      start: () => window.innerWidth <= 720 ? "top 17%" : "top 22%",
      end: () => `+=${Math.max(1500, teamMembers.length * window.innerHeight * 0.32)}`,
      pin: ".team-carousel",
      pinSpacing: true,
      anticipatePin: 1,
      onUpdate: (trigger) => {
        const nextIndex = Math.min(teamMembers.length - 1, Math.floor(trigger.progress * teamMembers.length))
        if (teamScrollIndex.value !== nextIndex) {
          teamScrollIndex.value = nextIndex
          setTeamIndex(nextIndex)
        }
      },
    })

    gsap.to(".journey-companion", {
      top: "78vh",
      ease: "none",
      scrollTrigger: {
        trigger: ".site-shell",
        start: "top top",
        end: "bottom bottom",
        scrub: 0.8,
        onUpdate: (trigger) => {
          const companion = document.querySelector<HTMLElement>(".journey-companion")
          if (!companion) return
          companion.dataset.docked = String(trigger.progress > 0.96)
          const count = companion.querySelector<HTMLElement>(".journey-count")
          if (count) count.textContent = `${Math.round(trigger.progress * 100)}%`
        },
      },
    })

    gsap.to(".journey-orbit", {
      rotation: 540,
      ease: "none",
      scrollTrigger: { trigger: ".site-shell", start: "top top", end: "bottom bottom", scrub: 0.8 },
    })

    gsap.utils.toArray<HTMLElement>("[data-parallax]").forEach((element, index) => {
      gsap.fromTo(element, {
        y: 42 + (index % 3) * 12,
        rotateX: 5,
        transformPerspective: 1100,
        transformOrigin: "50% 50%",
      }, {
        y: -38 - (index % 3) * 10,
        rotateX: -4,
        ease: "none",
        scrollTrigger: { trigger: element, start: "top bottom", end: "bottom top", scrub: 0.8 },
      })
    })
  }, { scope: page })

  const closeMenu = () => setMenuOpen(false)
  const visibleTeam = [-1, 0, 1].map((offset) => {
    const index = (teamIndex + offset + teamMembers.length) % teamMembers.length
    return { ...teamMembers[index], carouselIndex: index, offset }
  })

  function moveTeam(direction: number) {
    setTeamIndex((current) => (current + direction + teamMembers.length) % teamMembers.length)
  }

  function handleSubscribe(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!email.trim()) return
    setFormMessage("Thanks — the signup form is ready to connect to EDC updates.")
    setEmail("")
  }

  function handleJoin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setJoinMessage("Thanks for your interest! This form is a prototype and needs the EDC's official application inbox to receive submissions.")
    event.currentTarget.reset()
  }

  return (
    <div className="site-shell" ref={page}>
      <CursorFX />
      <div className="announcement"><span className="pulse-dot" /> A launchpad for the next big thing <a href={collegeUrl} target="_blank" rel="noreferrer">SIRT · BHOPAL <ArrowUpRight size={11} /></a></div>
      <header className="site-header container">
        <a className="brand" href="#home" aria-label="EDC SIRT home" onClick={closeMenu}>
          <span className="brand-logo-wrap"><img src="/edc-logo.png" alt="" /></span>
          <span className="brand-lockup"><b>EDC<span>.</span>SIRT</b><small>ENTREPRENEURSHIP DEVELOPMENT CELL</small></span>
        </a>
        <button className="mobile-menu" onClick={() => setMenuOpen((open) => !open)} aria-expanded={menuOpen} aria-controls="main-navigation">
          {menuOpen ? <><X size={16} /> CLOSE</> : <><Menu size={16} /> MENU</>}
        </button>
        <AnimatePresence>
          <motion.nav
            id="main-navigation"
            className={`main-nav ${menuOpen ? "is-open" : ""}`}
            initial={false}
            animate={{ opacity: 1, y: 0 }}
            aria-label="Main navigation"
          >
            {[ ["About", "#about"], ["Programs", "#programs"], ["Activity", "#activity"], ["Gallery", "#gallery"], ["Team", "#team"] ].map(([label, href]) => (
              <a href={href} key={label} onClick={closeMenu}>{label}</a>
            ))}
            <Button asChild size="sm"><a href="#join" onClick={closeMenu}>Join EDC <ArrowUpRight size={14} /></a></Button>
          </motion.nav>
        </AnimatePresence>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-grid" aria-hidden="true" />
          <div className="hero-inner container">
            <div className="hero-copy">
              <div className="hero-eyebrow eyebrow"><span className="pulse-dot" /> STUDENT IDEAS · SIRT BHOPAL</div>
              <h1 className="hero-title" aria-label="IDEAS MAKE NOISE."><span className="title-line"><SplitChars text="IDEAS" /></span><span className="title-line"><span className="title-outline"><SplitChars text="MAKE" /></span> <span className="title-lime"><SplitChars text="NOISE." /></span></span></h1>
              <KineticCopy className="hero-description" text="Take the first spark further. EDC SIRT helps students explore entrepreneurship, shape ideas, and find the support to build." />
              <div className="hero-actions"><Button asChild><a href="#join">Join the EDC <ArrowUpRight size={15} /></a></Button><a className="quiet-link" href="#about">Meet your launchpad <ArrowDownRight size={14} /></a></div>
              <a className="hero-scroll" href="#about"><span>01</span><i /><span>SCROLL TO EXPLORE</span><ArrowDown size={13} /></a>
            </div>
            <div className="hero-scene-wrap"><WebGLScene /><div className="hero-coordinate"><span>BUILT FOR<br /><b>WHAT’S NEXT.</b></span><Asterisk size={26} /></div></div>
            <div className="hero-counter">BHOPAL / <span>INDIA</span><b>23°15' N&nbsp; 77°24' E</b></div>
          </div>
        </section>

        <div className="ticker" aria-hidden="true"><div className="ticker-track">{Array.from({ length: 2 }).map((_, index) => <div className="ticker-row" key={index}>{["IDEATE", "INNOVATE", "INCUBATE", "MAKE IT REAL", "GO AGAIN"].map((item) => <span key={`${index}-${item}`}>{item}<Asterisk size={15} /></span>)}</div>)}</div></div>

        <section className="section about-section" id="about">
          <div className="container">
            <SectionHeading eyebrow="01 / THE CELL" title="BIG IDEAS START" accent="SOMEWHERE." note="A student-first space to ask better questions, find a first step, and keep building." />
            <div className="about-layout">
              <motion.div className="about-statement" initial={{ opacity: 0, x: -22 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.65 }}>
                <SectionScene variant="orbit" />
                <span className="about-asterisk"><Asterisk size={32} /></span>
                <h3>Turn “what if?”<br /><span>into “what’s next?”</span></h3>
                <p>Entrepreneurship Development Cell · Sagar Institute of Research and Technology</p>
              </motion.div>
              <div className="about-copy js-reveal">
                <div className="eyebrow">THE WHY / THE HOW</div>
                <KineticCopy text="At SIRT, EDC works to strengthen entrepreneurial qualities and help students move promising ideas toward products, services, and ventures. The cell’s published support includes planning, mentoring, execution guidance, seminars, workshops, and connections with mentors and industry experts." />
                <div className="mission-grid">
                  <div><span>OUR VISION</span><p>Entrepreneurs with strong ethics, leadership, and ideas ready to make an impact.</p></div>
                  <div><span>OUR MISSION</span><p>Build an environment where new ideas can grow and meet the real world.</p></div>
                </div>
                <a className="inline-link" href={edcUrl} target="_blank" rel="noreferrer">Read about EDC at SIRT <ArrowUpRight size={14} /></a>
              </div>
            </div>
          </div>
        </section>

        <section className="section programs-section" id="programs">
          <SectionScene variant="programs" />
          <div className="container">
            <SectionHeading eyebrow="02 / YOUR FIRST MOVES" title="A SPARK NEEDS" accent="A NEXT STEP." note="From the EDC’s published activity list: ways to learn, practise, and put your idea into words." />
            <div className="program-grid">{programs.map((program, index) => (
              <motion.div key={program.number} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.18 }} transition={{ delay: index * 0.1, duration: 0.6 }} whileHover={{ y: -8, rotateX: 3, rotateY: index % 2 ? -3 : 3 }} style={{ transformPerspective: 1200 }}>
                <Card className={`program-card program-${program.color}`}>
                  <CardHeader><div className="program-top"><span>{program.number} / THE PLAYBOOK</span><ArrowUpRight size={17} /></div><div className="program-mark">{program.mark}</div><span className="program-tag">{program.tag}</span><CardTitle>{program.title}</CardTitle></CardHeader>
                  <CardContent><CardDescription className="kinetic-copy" aria-label={program.copy}><SplitWords text={program.copy} /></CardDescription><a href={edcUrl} target="_blank" rel="noreferrer" aria-label={`Read more about ${program.title} on SIRT's website`}><ArrowRight size={17} /></a></CardContent>
                </Card>
              </motion.div>
            ))}</div>
            <div className="program-note"><span className="pulse-dot" /> EDC SIRT EVENT LIST <span>Business planning · communication · digital marketing · more</span><ArrowUpRight size={13} /></div>
          </div>
        </section>

        <section className="section activity-section" id="activity">
          <div className="container">
            <SectionHeading eyebrow="03 / THE MOMENTUM" title="IDEAS, OUT" accent="IN THE WORLD." note="A few moments from the EDC’s published archive. Your chapter can be next." />
            <div className="activity-feature js-reveal">
              <div className="feature-graphic" data-parallax><SectionScene variant="impact" /><div className="graphic-ring ring-a" /><div className="graphic-ring ring-b" /><span>WIN<br /><b>₹20K</b></span><i className="graphic-star">✳</i><small>JLU BHOPAL<br />INTER-UNIVERSITY PITCH</small></div>
              <div className="feature-copy"><span className="eyebrow lime-text">SIRT EDC / PANI WALA TEAM / 2024</span><h3>A local problem.<br />A winning pitch.</h3><KineticCopy text="The SIRT EDC team Pani Wala won an inter-university business pitching competition at JLU Bhopal." /><a className="inline-link" href={edcUrl} target="_blank" rel="noreferrer">See the EDC archive <ArrowUpRight size={14} /></a></div>
            </div>
            <div className="activity-list">{activities.slice(1).map((item, index) => <motion.article className="activity-row" key={item.number} initial={{ opacity: 0, x: -18 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ delay: index * 0.1 }}><span className="activity-index">{item.number}</span><span className="activity-date">{item.date}</span><div><span className="activity-category">{item.category}</span><h3>{item.title}</h3><KineticCopy text={item.body} /></div><ArrowUpRight className="activity-arrow" size={18} /></motion.article>)}</div>
          </div>
        </section>

        <section className="section gallery-section" id="gallery">
          <div className="container">
            <SectionHeading eyebrow="04 / THE GALLERY" title="IDEAS DON’T" accent="HAPPEN ALONE." note="Real moments from the EDC at SIRT. Drag a card to explore." />
          </div>
          <div className="gallery-rail" aria-label="Swipeable EDC photo gallery">{galleryImages.map((image, index) => <motion.a className={`gallery-card gallery-card-${index + 1}`} href={image.src} target="_blank" rel="noreferrer" key={image.index} drag="x" dragElastic={0.16} data-cursor-label="DRAG" whileHover={{ y: -8, rotate: index % 2 ? 1 : -1 }} whileTap={{ scale: 0.98 }}>
            <img src={image.src} alt={image.title} loading="lazy" onError={(event) => { event.currentTarget.style.display = "none" }} /><span className="gallery-overlay" /><span className="gallery-meta"><small>EDC SIRT / {image.index}</small><b>{image.title}</b><ArrowUpRight size={16} /></span>
          </motion.a>)}</div>
          <div className="container gallery-foot"><span>PHOTOS: SIRT EDC ARCHIVE</span><span>DRAG TO EXPLORE <MoveUpRight size={12} /></span></div>
        </section>

        <section className="section team-section" id="team">
          <SectionScene variant="team" />
          <div className="container">
            <SectionHeading eyebrow="05 / THE PEOPLE" title="GOOD PEOPLE" accent="MAKE IT HAPPEN." note="Students, mentors, faculty, and industry voices move the EDC ecosystem forward." />
            <div className="team-carousel js-reveal" role="region" aria-roledescription="carousel" aria-label="EDC team placeholders">
              <div className="team-carousel-stage" aria-live="polite">
                {visibleTeam.map((member) => <article className={`team-card team-slide team-card-${member.carouselIndex + 1} ${member.offset === 0 ? "is-active" : ""}`} key={member.index} aria-hidden={member.offset !== 0} data-cursor-label="MEET" style={{ transform: `translateX(calc(-50% + ${member.offset * 73}%)) perspective(1100px) rotateY(${member.offset * -25}deg) scale(${member.offset === 0 ? 1 : 0.78})`, clipPath: member.offset === 0 ? "inset(0 0 0 0)" : member.offset < 0 ? "inset(0 72% 0 0)" : "inset(0 0 0 72%)", opacity: member.offset === 0 ? 1 : 0.48, zIndex: 3 - Math.abs(member.offset) }}>
                  <div className="team-visual"><div className="portrait-orbit" /><div className="portrait-core"><span>ADD<br />PHOTO</span></div><div className="team-spark">✳</div><span className="team-index">{member.index}</span></div><span className="eyebrow">PLACEHOLDER / {member.index}</span><h3>{member.name}</h3><p>{member.role}</p>
                </article>)}
              </div>
          <div className="team-carousel-controls">
                <button className="team-arrow" type="button" aria-label="Previous team placeholder" onClick={() => moveTeam(-1)}><ChevronLeft size={19} /></button>
                <div className="team-dots" aria-label="Choose a team placeholder">{teamMembers.map((member, index) => <button className={teamIndex === index ? "is-active" : ""} type="button" key={member.index} aria-label={`Show ${member.role} placeholder`} aria-current={teamIndex === index ? "true" : undefined} onClick={() => setTeamIndex(index)} />)}</div>
                <span className="team-count">{String(teamIndex + 1).padStart(2, "0")} / {String(teamMembers.length).padStart(2, "0")}</span>
                <button className="team-arrow" type="button" aria-label="Next team placeholder" onClick={() => moveTeam(1)}><ChevronRight size={19} /></button>
              </div>
            </div>
            <p className="team-note">Replace each placeholder with the current EDC member’s photo, name, and role.</p>
          </div>
        </section>

        <section className="section contact-section" id="contact">
          <div className="container contact-layout">
            <div className="contact-copy js-reveal"><div className="eyebrow lime-text">06 / OPEN INVITATION</div><h2>Bring us<br />your <em>what if.</em></h2><KineticCopy text="Have a question, a half-built idea, or a problem you can’t stop thinking about? Start a conversation with SIRT." /><Button asChild><a href="#join">Apply to the EDC <ArrowUpRight size={15} /></a></Button></div>
            <div className="contact-panel js-reveal"><div className="contact-panel-top"><span>YOUR NEXT STEP</span><span>BHOPAL / INDIA</span></div><h3>Every venture starts<br />with a conversation.</h3><KineticCopy text="Ask about seminars, workshops, mentoring, and the best way to get involved with the Entrepreneurship Development Cell." /><div className="contact-details"><a href="tel:+917554983150"><Phone size={14} /> +91 755 498 3150 <ArrowUpRight size={12} /></a><a href={collegeUrl} target="_blank" rel="noreferrer">SIRT Bhopal <ArrowUpRight size={12} /></a></div></div>
          </div>
        </section>

        <section className="subscribe-section"><div className="container subscribe-inner"><div><span className="eyebrow">THE NEXT BIG THING</span><h2>Stay in the loop.</h2><p>Get updates when the EDC announces its next move.</p></div><form onSubmit={handleSubscribe} className="subscribe-form"><label className="sr-only" htmlFor="email">Email address</label><input id="email" type="email" placeholder="Your email address" value={email} onChange={(event) => { setEmail(event.target.value); setFormMessage("") }} required /><button type="submit" aria-label="Subscribe for updates"><ArrowUpRight size={18} /></button>{formMessage && <p className="subscribe-message" role="status">{formMessage}</p>}</form></div></section>

        <section className="join-section" id="join">
          <div className="container join-layout">
            <div className="join-intro js-reveal"><span className="eyebrow">07 / YOUR NEXT MOVE</span><h2>MAKE<br />SOME <em>NOISE.</em></h2><p>Bring your curiosity, your questions, and the idea you keep coming back to. Tell us a little about yourself.</p><div className="join-stamp"><span>EDC</span><b>SIRT / BHOPAL</b><i>APPLICATIONS OPEN</i></div></div>
            <form className="join-form js-reveal" onSubmit={handleJoin}>
              <div className="join-form-heading"><span className="eyebrow">JOIN THE CELL / 2026</span><span>01—06</span></div>
              <div className="join-fields">
                <label>YOUR NAME<input name="name" autoComplete="name" placeholder="e.g. Aditi Sharma" required /></label>
                <label>COLLEGE EMAIL<input name="email" type="email" autoComplete="email" placeholder="you@college.edu" required /></label>
                <label>BRANCH / DEPARTMENT<input name="department" placeholder="e.g. Computer Science" required /></label>
                <label>YEAR OF STUDY<select name="year" defaultValue="" required><option value="" disabled>Select year</option><option>1st year</option><option>2nd year</option><option>3rd year</option><option>4th year</option></select></label>
                <label className="join-field-wide">WHAT WOULD YOU LIKE TO EXPLORE?<select name="interest" defaultValue="" required><option value="" disabled>Choose an area</option><option>Startup ideas & product building</option><option>Events & community</option><option>Marketing & outreach</option><option>Design, media & storytelling</option><option>Research, strategy & operations</option></select></label>
                <label className="join-field-wide">WHAT MAKES YOU CURIOUS?<textarea name="motivation" rows={3} placeholder="Tell us about a problem, idea, or skill you want to grow." required /></label>
              </div>
              <div className="join-form-footer"><p>We’ll use this to start a conversation about getting involved.</p><Button type="submit">Send interest <ArrowUpRight size={15} /></Button></div>
              {joinMessage && <p className="join-message" role="status">{joinMessage}</p>}
            </form>
          </div>
        </section>
      </main>

      <a className="journey-companion" href="#join" aria-label="Scroll progress. Click to join EDC." data-cursor-label="FOLLOW">
        <span className="journey-orbit"><span className="journey-core">✳</span><i /><b /></span>
        <span className="journey-count">00%</span>
        <span className="journey-dock-label">JOIN EDC <ArrowUpRight size={12} /></span>
      </a>

      <footer className="site-footer"><div className="container"><div className="footer-main"><a className="brand" href="#home"><span className="brand-logo-wrap"><img src="/edc-logo.png" alt="" /></span><span className="brand-lockup"><b>EDC<span>.</span>SIRT</b><small>ENTREPRENEURSHIP DEVELOPMENT CELL</small></span></a><p>Ideate. Innovate. Incubate.<br /><span>A little noise from Bhopal.</span></p><div className="footer-links"><a href="#about">About</a><a href="#programs">Programs</a><a href="#activity">Activity</a><a href="#gallery">Gallery</a><a href="#team">The people</a><a href="#join">Join EDC</a><a href={edcUrl} target="_blank" rel="noreferrer">Official EDC page <ArrowUpRight size={12} /></a></div></div><div className="footer-bottom"><span>© EDC SIRT BHOPAL</span><span>MADE OF BIG IDEAS <Asterisk size={14} /></span><a href={collegeUrl} target="_blank" rel="noreferrer">SAGAR INSTITUTE OF RESEARCH & TECHNOLOGY <ArrowUpRight size={12} /></a></div></div></footer>
    </div>
  )
}

export default App
