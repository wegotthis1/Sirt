# EDC SIRT launchpad

A React + Vite landing page for the Entrepreneurship Development Cell at SIRT Bhopal. Its content follows the E-Cell structure of an editorial home page, about, programs and events, gallery, people, contact, and updates. SIRT-specific copy and archive highlights are based on the college's published [EDC page](https://www.sirtbhopal.ac.in/entrepreneurship-development-cell).

## Run locally

Do not open `index.html` by double-clicking it: this is a Vite app and needs its dev server.
On Windows, double-click `start.bat`. Keep its terminal window open, then visit the local URL Vite prints (usually `http://localhost:5173/`) in a browser on the same machine. Codex's embedded browser may not be able to reach a local dev server. Or run:

```sh
npm install
npm run dev
```

Keep the terminal running while using the site.

To create a standalone file that does not need a dev server, run `npm run build:offline` and open `dist/standalone.html` in Chrome or Edge. Images and fonts still load from the internet.

To check the production build locally:

```sh
npm run build
npm run preview
```

The site uses React, Three.js through React Three Fiber, GSAP + ScrollTrigger for page and scroll motion, Framer Motion for interactive cards, and local shadcn/ui components configured in `components.json`.

The image rail uses the SIRT EDC photo archive. The Join EDC application and updates forms are front-end prototypes; connect them to an approved intake endpoint before collecting submissions.
