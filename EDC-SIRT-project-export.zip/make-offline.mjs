import { readFile, writeFile } from "node:fs/promises"
import { join } from "node:path"

const dist = join(process.cwd(), "dist")
let html = await readFile(join(dist, "index.html"), "utf8")

const scriptMatch = html.match(/<script\s+type="module"[^>]*src="([^"]+\.js)"[^>]*><\/script>/)
const styleMatch = html.match(/<link\s+rel="stylesheet"[^>]*href="([^"]+\.css)"[^>]*>/)

if (!scriptMatch || !styleMatch) {
  throw new Error("Could not find the built JavaScript and CSS assets in dist/index.html")
}

const scriptPath = join(dist, scriptMatch[1].replace(/^\//, ""))
const stylePath = join(dist, styleMatch[1].replace(/^\//, ""))
const [script, style, logo] = await Promise.all([
  readFile(scriptPath, "utf8"),
  readFile(stylePath, "utf8"),
  readFile(join(dist, "edc-logo.png")),
])
const inlineLogo = `data:image/png;base64,${logo.toString("base64")}`

html = html
  .replace(scriptMatch[0], () => `<script type="module">\n${script.replaceAll('"/edc-logo.png"', JSON.stringify(inlineLogo)).replace(/<\/script/gi, "<\\/script")}\n</script>`)
  .replace(styleMatch[0], () => `<style>\n${style.replace(/<\/style/gi, "<\\/style")}\n</style>`)

await writeFile(join(dist, "standalone.html"), html)
console.log("Created dist/standalone.html")
